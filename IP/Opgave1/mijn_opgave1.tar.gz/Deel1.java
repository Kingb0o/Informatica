/*
* Naam : W. van der LInde
* UvAnetID : 12857130
* Studie : BSc Informatica
*
* Deel1.java:
* -Dit programma print mijn eigen naam in ASCII-art.
* -Dit gebeurd door simpel gebruik te maken van println()
*/

public class Deel1 {
    public static void main(String[] args){
        System.out.println(" __      __                            .__  ");
        System.out.println("/  \\    /  \\ ____   ______ ______ ____ |  | ");
        System.out.println("\\   \\/\\/   // __ \\ /  ___//  ___// __ \\|  |");
        System.out.println(" \\        /\\  ___/ \\___ \\ \\___ \\\\  ___/|  |");
        System.out.println("  \\__/\\  /  \\___  >____  >____  >\\___  >____/");
        System.out.println("       \\/       \\/     \\/     \\/     \\/      ");
        System.out.println("_");
    }
}